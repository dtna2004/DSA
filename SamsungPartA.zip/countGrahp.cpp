#include <iostream>
#include <vector>
using namespace std;

// Hàm tính giai thừa
int factorial(int n) {
    if (n <= 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

// Hàm tính tổ hợp C(n, k)
int combination(int n, int k) {
    return factorial(n) / (factorial(k) * factorial(n - k));
}

// Hàm đếm số đồ thị vô hướng có V đỉnh, E cạnh (không có cạnh song song)
int countGraphs(int V, int E) {
    if (E > combination(V, 2)) {
        // Số cạnh không hợp lệ
        return 0;
    }

    // Số đồ thị = C(V*(V-1)/2, E)
    return combination(V * (V - 1) / 2, E);
}

int main() {
    // Nhập số đỉnh và số cạnh
    int V, E;
    cout << "Nhap so dinh (V): ";
    cin >> V;
    cout << "Nhap so canh (E): ";
    cin >> E;

    // Gọi hàm đếm số đồ thị
    int result = countGraphs(V, E);

    // Hiển thị kết quả
    cout << "So do thi vo huong co " << V << " dinh va " << E << " canh la: " << result << endl;

    return 0;
}
