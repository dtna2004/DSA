
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Graph {
private:
    int V;
    vector<vector<int>> adj;

public:
    Graph(int v) : V(v), adj(v) {}

    void addEdge(int u, int v) {
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    bool isIsolated(int v) {
        return adj[v].empty();
    }

    // Kiểm tra đồ thị có chu trình Euler hay không
    bool hasEulerCycle() {
        for (int i = 0; i < V; i++) {
            if (adj[i].size() % 2 != 0 || isIsolated(i))
                return false;
        }
        return true;
    }

    bool hasHamiltonCycle() {
        vector<int> path(V, -1);
        path[0] = 0;

        return hamiltonCycleUtil(path, 1);
    }

private:
    bool hamiltonCycleUtil(vector<int>& path, int pos) {
        if (pos == V) {
            if (adj[path[pos - 1]][path[0]] == 1)
                return true;
            else
                return false;
        }

        for (int v = 1; v < V; v++) {
            if (isSafe(v, pos, path)) {
                path[pos] = v;

                if (hamiltonCycleUtil(path, pos + 1))
                    return true;

                path[pos] = -1;
            }
        }

        return false;
    }

    bool isSafe(int v, int pos, const vector<int>& path) {
        if (adj[path[pos - 1]][v] == 0)
            return false;

        for (int i = 0; i < pos; i++)
            if (path[i] == v)
                return false;

        return true;
    }
};

int main() {

    Graph graph1(10);
    graph1.addEdge(0, 1);
    graph1.addEdge(0, 2);
    graph1.addEdge(0, 3);
    graph1.addEdge(1, 3);
    graph1.addEdge(1, 4);
    graph1.addEdge(2, 5);
    graph1.addEdge(2, 9);
    graph1.addEdge(3, 6);
    graph1.addEdge(4, 7);
    graph1.addEdge(4, 8);
    graph1.addEdge(5, 8);
    graph1.addEdge(5, 9);
    graph1.addEdge(6, 7);
    graph1.addEdge(6, 9);
    graph1.addEdge(7, 8);

    Graph graph2(10);
    graph2.addEdge(0, 1);
    graph2.addEdge(0, 2);
    graph2.addEdge(0, 3);
    graph2.addEdge(1, 3);
    graph2.addEdge(0, 3);
    graph2.addEdge(2, 5);
    graph2.addEdge(5, 6);
    graph2.addEdge(3, 6);
    graph2.addEdge(4, 7);
    graph2.addEdge(4, 8);
    graph2.addEdge(5, 8);
    graph2.addEdge(5, 9);
    graph2.addEdge(6, 7);
    graph2.addEdge(6, 9);
    graph2.addEdge(8, 8);

    Graph graph3(10);
    graph3.addEdge(0, 1);
    graph3.addEdge(1, 2);
    graph3.addEdge(1, 3);
    graph3.addEdge(0, 3);
    graph3.addEdge(0, 4);
    graph3.addEdge(2, 5);
    graph3.addEdge(2, 9);
    graph3.addEdge(3, 6);
    graph3.addEdge(4, 7);
    graph3.addEdge(4, 8);
    graph3.addEdge(5, 8);
    graph3.addEdge(5, 9);
    graph3.addEdge(6, 7);
    graph3.addEdge(6, 9);
    graph3.addEdge(7, 8);

    Graph graph4(10);
    graph4.addEdge(4, 1);
    graph4.addEdge(7, 9);
    graph4.addEdge(6, 2);
    graph4.addEdge(7, 3);
    graph4.addEdge(5, 0);
    graph4.addEdge(0, 2);
    graph4.addEdge(0, 8);
    graph4.addEdge(1, 6);
    graph4.addEdge(3, 9);
    graph4.addEdge(6, 3);
    graph4.addEdge(2, 8);
    graph4.addEdge(1, 5);
    graph4.addEdge(9, 8);
    graph4.addEdge(4, 5);
    graph4.addEdge(4, 7);

   if(graph1.hasEulerCycle()){
        cout << "chu trinh 1 has euler\n";
   }
   if(graph2.hasEulerCycle()){
        cout << "chu trinh 2 has euler\n";
   }
   if(graph3.hasEulerCycle()){
        cout << "chu trinh 3 has euler\n";
   }
   if(graph4.hasEulerCycle()){
        cout << "chu trinh 4 has euler\n";
   }
   if(graph1.hasHamiltonCycle()){
        cout << "chu trinh 1 has HamiltonCycle\n";
   }
   if(graph2.hasHamiltonCycle()){
        cout << "chu trinh 2 has HamiltonCycle\n";
   }
   if(graph3.hasHamiltonCycle()){
        cout << "chu trinh 3 has HamiltonCycle\n";
   }
   if(graph4.hasHamiltonCycle()){
        cout << "chu trinh 4 has HamiltonCycle\n";
   }

    return 0;
}
