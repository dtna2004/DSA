#include <iostream>
#include <vector>

using namespace std;

// Kích thước của ảnh
const int ROWS = 4;
const int COLS = 4;

// Hàm kiểm tra xem một điểm ảnh có hợp lệ không
bool isValid(int x, int y, vector<vector<int>>& image, int targetColor) {
    return x >= 0 && x < ROWS && y >= 0 && y < COLS && image[x][y] == targetColor;
}

// Hàm floodfill sử dụng DFS
void floodFillDFS(int x, int y, vector<vector<int>>& image, int targetColor, int newColor) {
    if (!isValid(x, y, image, targetColor)) {
        return;
    }

    // Đổi màu cho điểm ảnh hiện tại
    image[x][y] = newColor;

    // Kiểm tra và gọi đệ quy cho các điểm ảnh kề nhau
    floodFillDFS(x + 1, y, image, targetColor, newColor);
    floodFillDFS(x - 1, y, image, targetColor, newColor);
    floodFillDFS(x, y + 1, image, targetColor, newColor);
    floodFillDFS(x, y - 1, image, targetColor, newColor);
}

// Hàm in ảnh
void printImage(const vector<vector<int>>& image) {
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j) {
            cout << image[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    // Ảnh ban đầu
    vector<vector<int>> image = {
        {1, 1, 1, 0},
        {1, 0, 1, 1},
        {1, 0, 0, 1},
        {1, 1, 1, 1}
    };

    // Điểm bắt đầu floodfill
    int startRow = 1;
    int startCol = 1;

    // Màu mới
    int newColor = 2;

    // Lưu màu ban đầu của điểm bắt đầu
    int targetColor = image[startRow][startCol];

    // Kiểm tra xem màu mới có khác màu cũ không
    if (targetColor != newColor) {
        floodFillDFS(startRow, startCol, image, targetColor, newColor);

        cout << "Anh sau khi floodfill:" << endl;
        printImage(image);
    } else {
        cout << "Mau moi phai khac mau cu." << endl;
    }

    return 0;
}

