#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Graph {
public:
    int V;
    vector<vector<int>> adjList;

    Graph(int vertices) : V(vertices), adjList(vertices) {}

    void addEdge(int u, int v) {
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }

    void dfs(int u, vector<bool>& visited) {
        visited[u] = true;

        for (int v : adjList[u]) {
            if (!visited[v]) {
                dfs(v, visited);
            }
        }
    }

    bool isEdgeConnected() {
        for (int u = 0; u < V; ++u) {
            for (int v : adjList[u]) {
                auto it = find(adjList[u].begin(), adjList[u].end(), v);
                if (it != adjList[u].end()) {
                    adjList[u].erase(it);
                }

                it = find(adjList[v].begin(), adjList[v].end(), u);
                if (it != adjList[v].end()) {
                    adjList[v].erase(it);
                }

                vector<bool> visited(V, false);
                dfs(u, visited);

                if (find(visited.begin(), visited.end(), false) != visited.end()) {
                    cout << "do thi khong lien thong canh" << endl;
                    return false;
                }
                adjList[u].push_back(v);
                adjList[v].push_back(u);
            }
        }

        cout << "Do thi la do thi lien thong canh." << endl;
        return true;
    }
};

int main() {
    Graph graph(4);

    // Thêm cạnh vào đồ thị
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 3);
    graph.addEdge(1, 3);

    graph.isEdgeConnected();

    return 0;
}
