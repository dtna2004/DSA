
#include <iostream>
#include <vector>
#include <stack>

using namespace std;

class Graph {
public:
    int V;
    vector<vector<int>> adjList;

    Graph(int vertices) : V(vertices), adjList(vertices) {}

    void addEdge(int u, int v) {
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }

    void dfs(int u, vector<int>& disc, vector<int>& low, vector<int>& parent, vector<pair<int, int>>& bridges, int& time) {
        disc[u] = low[u] = ++time;

        for (int v : adjList[u]) {
            if (!disc[v]) {
                parent[v] = u;
                dfs(v, disc, low, parent, bridges, time);

                low[u] = min(low[u], low[v]);

                if (low[v] > disc[u]) {
                    bridges.push_back({u, v});
                }
            } else if (v != parent[u]) {
                low[u] = min(low[u], disc[v]);
            }
        }
    }

    bool isBiconnected() {
        vector<int> disc(V, 0);
        vector<int> low(V, 0);
        vector<int> parent(V, -1);
        vector<pair<int, int>> bridges;
        int time = 0;

        dfs(0, disc, low, parent, bridges, time);

        if (!bridges.empty()) {
            cout << "Do thi khong la do thi biconnected." << endl;
            return false;
        }

        cout << "Do thi la do thi biconnected." << endl;
        return true;
    }
};

int main() {
    Graph graph(5);
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 0);
    graph.addEdge(1, 3);
    graph.addEdge(3, 4);

    graph.isBiconnected();

    return 0;
}
