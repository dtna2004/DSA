#include <iostream>
#include <vector>
#include <queue>
#include <unordered_set>

using namespace std;

class Graph {
public:
    int V;
    vector<vector<int>> adjList;

    Graph(int vertices) : V(vertices), adjList(vertices) {}

    void addEdge(int u, int v) {
        adjList[u].push_back(v);
        adjList[v].push_back(u);
    }

    bool isBipartite() {
        vector<int> color(V, -1);
        queue<int> q;

        for (int i = 0; i < V; ++i) {
            if (color[i] == -1) {
                color[i] = 0;

                q.push(i);

                while (!q.empty()) {
                    int u = q.front();
                    q.pop();

                    for (int v : adjList[u]) {
                        if (color[v] == -1) {
                            color[v] = 1 - color[u]; // Đổi màu
                            q.push(v);
                        } else if (color[v] == color[u]) {
                            return false;
                        }
                    }
                }
            }
        }

        return true;
    }
};

int main() {
    Graph graph(4);

    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 3);
    graph.addEdge(3, 0);
    //graph.addEdge(0, 2);

    if (graph.isBipartite()) {
        cout << "Do thi la do thi hai mau." << endl;
    } else {
        cout << "Do thi khong phai la do thi hai mau." << endl;
    }

    return 0;
}
