#include <iostream>
#include <vector>
#include <unordered_set>

using namespace std;

// Định nghĩa cạnh của đồ thị
struct Edge {
    int src, dest;
};

// Lớp đại diện cho đồ thị vô hướng
class Graph {
public:
    int V; // Số đỉnh
    vector<Edge> edges; // Danh sách cạnh

    // Constructor
    Graph(int V) : V(V) {}

    // Thêm cạnh vào đồ thị
    void addEdge(int src, int dest) {
        edges.push_back({src, dest});
    }

    // Đếm số cạnh song song trong đồ thị
    int countParallelEdges() {
        unordered_set<int> uniqueEdges; // Sử dụng set để theo dõi cạnh duy nhất
        int parallelEdges = 0;

        for (const Edge& edge : edges) {
            // Sắp xếp đỉnh để có thứ tự (u, v) giống nhau nếu cùng một cạnh
            int u = min(edge.src, edge.dest);
            int v = max(edge.src, edge.dest);
            int encodedEdge = u * V + v;

            // Kiểm tra xem cạnh đã xuất hiện trước đó chưa
            if (uniqueEdges.count(encodedEdge) > 0) {
                parallelEdges++;
            } else {
                // Nếu chưa xuất hiện, thêm cạnh vào set
                uniqueEdges.insert(encodedEdge);
                uniqueEdges.insert(encodedEdge + V);  // Chỉnh sửa ở đây
            }
        }

        return parallelEdges;
    }
};

int main() {
    // Tạo đồ thị với 4 đỉnh
    Graph graph(4);

    // Thêm cạnh vào đồ thị
    graph.addEdge(0, 1);
    graph.addEdge(1, 2);
    graph.addEdge(2, 3);
    graph.addEdge(3, 3);
    graph.addEdge(2, 2);

    // Đếm số cạnh song song
    int parallelEdges = graph.countParallelEdges();

    // Hiển thị kết quả
    cout << "So canh song song trong do thi la: " << parallelEdges << endl;

    return 0;
}
